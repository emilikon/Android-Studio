package com.example.emilikon_oblig1

data class Question(val spm: String,val sannUsann: Boolean)